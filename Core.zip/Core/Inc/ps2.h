#ifndef PS2_H
#define PS2_H

#include "main.h"
#include <stdint.h>

typedef struct
{
    uint8_t connected;   /* 1 = 收到合法数据 */
    uint8_t mode;        /* 0x41 = 数字模式，0x73 = 模拟模式 */
    uint8_t buttons1;
    uint8_t buttons2;
    uint8_t right_x;
    uint8_t right_y;
    uint8_t left_x;
    uint8_t left_y;
    uint8_t raw[9];      /* 一帧原始 9 字节，串口验证用 */
} PS2_Data_t;

extern PS2_Data_t ps2;

void PS2_Init(void);
uint8_t PS2_Read(void);
void PS2_PrintRaw(void);

/* PS2 按键是低电平有效，所以用 == 0 判断按下 */
#define PS2_BTN_PRESSED(byte, mask)  (((byte) & (mask)) == 0U)

/* buttons1 里的十字键位 */
#define PS2_DPAD_UP     0x10U
#define PS2_DPAD_RIGHT  0x20U
#define PS2_DPAD_DOWN   0x40U
#define PS2_DPAD_LEFT   0x80U

/* buttons2 里的肩键/扳机键位，备用 */
#define PS2_L2          0x01U
#define PS2_R2          0x02U
#define PS2_L1          0x04U
#define PS2_R1          0x08U

#endif
