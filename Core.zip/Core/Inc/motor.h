#ifndef MOTOR_H
#define MOTOR_H

#include <stdint.h>

typedef enum
{
    MOTOR_LF = 0,   /* 左前轮 A6/A7  -> TIM3_CH1/CH2 */
    MOTOR_LR,       /* 左后轮 B0/B1  -> TIM3_CH3/CH4 */
    MOTOR_RF,       /* 右前轮 A1/A0  -> TIM2_CH2/CH1 */
    MOTOR_RR        /* 右后轮 A2/A3  -> TIM2_CH3/CH4 */
} MotorId;

void Motor_Init(void);
void Motor_Set(MotorId id, int8_t direction);  /* 1 正转，-1 反转，0 停 */
void Motor_StopAll(void);

#endif
