#ifndef CONTROL_H
#define CONTROL_H

void Control_Init(void);
void Control_Loop(void);

#endif
