#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/* ======================= 工作模式 ======================= */
/* 1 = 只读手柄并通过串口打印原始数据，不驱动电机；调试完改成 0 */
#define PS2_TEST_MODE       0

/* 1 = 上电后依次测试四个轮子；调试完改成 0 */
#define WHEEL_TEST_MODE     1

/* ======================= 摇杆参数 ======================= */
/* 死区：摇杆偏离中心超过这个值才算动作，建议 30~50 */
#define STICK_DEADZONE      40

/* ======================= 电机参数 ======================= */
/* TIM2/TIM3 的 ARR = 99，所以 CCR=100 就是 100% 占空比 */
#define PWM_FULL            100U

/* 某个轮子方向反了，就把对应一行改成 1 */
#define MOTOR_LF_INVERT     1
#define MOTOR_LR_INVERT     0
#define MOTOR_RF_INVERT     0
#define MOTOR_RR_INVERT     0

/* 前进正常、但左右平移方向相反时，把这里改成 -1 */
#define MECANUM_STRAFE_SIGN 1

#endif
