#include "motor.h"
#include "app_config.h"
#include "main.h"

extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;

typedef struct
{
    TIM_HandleTypeDef *htim;
    uint32_t ch_a;
    uint32_t ch_b;
    uint8_t invert;
} MotorConfig_t;

/*
 * 每个电机两个 DRV8833 输入：
 * 正转 = A 高、B 低；反转 = A 低、B 高；停止 = A、B 都低。
 */
static const MotorConfig_t motor_cfg[4] =
{
    {&htim3, TIM_CHANNEL_1, TIM_CHANNEL_2, MOTOR_LF_INVERT},  /* A6 / A7 */
    {&htim3, TIM_CHANNEL_3, TIM_CHANNEL_4, MOTOR_LR_INVERT},  /* B0 / B1 */
    {&htim2, TIM_CHANNEL_2, TIM_CHANNEL_1, MOTOR_RF_INVERT},  /* A1 / A0 */
    {&htim2, TIM_CHANNEL_3, TIM_CHANNEL_4, MOTOR_RR_INVERT},  /* A2 / A3 */
};

static void motor_pwm(TIM_HandleTypeDef *htim, uint32_t channel, uint8_t on)
{
    __HAL_TIM_SET_COMPARE(htim, channel, on ? PWM_FULL : 0U);
}

void Motor_Init(void)
{
    for (uint32_t i = 0; i < 4U; i++)
    {
        (void)HAL_TIM_PWM_Start(motor_cfg[i].htim, motor_cfg[i].ch_a);
        (void)HAL_TIM_PWM_Start(motor_cfg[i].htim, motor_cfg[i].ch_b);
        motor_pwm(motor_cfg[i].htim, motor_cfg[i].ch_a, 0U);
        motor_pwm(motor_cfg[i].htim, motor_cfg[i].ch_b, 0U);
    }
}

void Motor_Set(MotorId id, int8_t direction)
{
    if ((uint32_t)id >= 4U)
    {
        return;
    }

    const MotorConfig_t *m = &motor_cfg[id];

    if (direction == 0)
    {
        motor_pwm(m->htim, m->ch_a, 0U);
        motor_pwm(m->htim, m->ch_b, 0U);
        return;
    }

    if (m->invert)
    {
        direction = (int8_t)(-direction);
    }

    if (direction > 0)
    {
        motor_pwm(m->htim, m->ch_b, 0U);
        motor_pwm(m->htim, m->ch_a, 1U);
    }
    else
    {
        motor_pwm(m->htim, m->ch_a, 0U);
        motor_pwm(m->htim, m->ch_b, 1U);
    }
}

void Motor_StopAll(void)
{
    for (uint32_t i = 0; i < 4U; i++)
    {
        Motor_Set((MotorId)i, 0);
    }
}
