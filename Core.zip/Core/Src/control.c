#include "control.h"
#include "app_config.h"
#include "ps2.h"
#include "motor.h"
#include "main.h"
#include <stdio.h>
#include <string.h>

extern UART_HandleTypeDef huart1;

static void uart_send(const char *s)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)s, (uint16_t)strlen(s), 100U);
}

static int8_t sign_i8(int8_t v)
{
    if (v > 0)
    {
        return 1;
    }
    if (v < 0)
    {
        return -1;
    }
    return 0;
}

/*
 * 麦轮运动学（二值化版）：
 * y = 1 前进，-1 后退
 * x = 1 右移，-1 左移
 * LF = y + x
 * RF = y - x
 * LR = y - x
 * RR = y + x
 *
 * 十字键左/右优先做原地旋转：
 * 左转：左边两轮后退，右边两轮前进
 * 右转：左边两轮前进，右边两轮后退
 */
static void drive_from_ps2(void)
{
    int16_t lx = (int16_t)ps2.left_x - 128;
    int16_t ly = (int16_t)ps2.left_y - 128;
    int8_t x = 0;
    int8_t y = 0;

    if (ly < -(int16_t)STICK_DEADZONE)
    {
        y = 1;          /* 摇杆向上推 */
    }
    else if (ly > (int16_t)STICK_DEADZONE)
    {
        y = -1;         /* 摇杆向下推 */
    }

    if (lx < -(int16_t)STICK_DEADZONE)
    {
        x = -1;         /* 摇杆向左推 */
    }
    else if (lx > (int16_t)STICK_DEADZONE)
    {
        x = 1;          /* 摇杆向右推 */
    }

    x = (int8_t)(x * MECANUM_STRAFE_SIGN);

    int8_t lf = (int8_t)(y + x);
    int8_t rf = (int8_t)(y - x);
    int8_t lr = (int8_t)(y - x);
    int8_t rr = (int8_t)(y + x);

    uint8_t rot_left  = PS2_BTN_PRESSED(ps2.buttons1, PS2_DPAD_LEFT);
    uint8_t rot_right = PS2_BTN_PRESSED(ps2.buttons1, PS2_DPAD_RIGHT);

    if (rot_left && rot_right)
    {
        Motor_StopAll();
        return;
    }

    if (rot_left)
    {
        lf = -1;
        rf =  1;
        lr = -1;
        rr =  1;
    }
    else if (rot_right)
    {
        lf =  1;
        rf = -1;
        lr =  1;
        rr = -1;
    }

    Motor_Set(MOTOR_LF, sign_i8(lf));
    Motor_Set(MOTOR_LR, sign_i8(lr));
    Motor_Set(MOTOR_RF, sign_i8(rf));
    Motor_Set(MOTOR_RR, sign_i8(rr));
}

#if WHEEL_TEST_MODE
static void wheel_test_run_once(void)
{
    static const MotorId ids[4] = {MOTOR_LF, MOTOR_LR, MOTOR_RF, MOTOR_RR};
    static const char *names[4] = {"LF A6/A7", "LR B0/B1", "RF A1/A0", "RR A2/A3"};
    char buf[80];

    for (uint32_t i = 0; i < 4U; i++)
    {
        (void)snprintf(buf, sizeof(buf), "WHEEL TEST: %s FORWARD\r\n", names[i]);
        uart_send(buf);
        Motor_Set(ids[i], 1);
        HAL_Delay(1000U);

        Motor_Set(ids[i], 0);
        HAL_Delay(500U);

        (void)snprintf(buf, sizeof(buf), "WHEEL TEST: %s REVERSE\r\n", names[i]);
        uart_send(buf);
        Motor_Set(ids[i], -1);
        HAL_Delay(1000U);

        Motor_Set(ids[i], 0);
        HAL_Delay(800U);
    }

    uart_send("WHEEL TEST DONE\r\n");
}
#endif

void Control_Init(void)
{
    Motor_Init();
    PS2_Init();
    HAL_Delay(300U);
    uart_send("\r\nMecanum PS2 ready\r\n");
}

void Control_Loop(void)
{
#if WHEEL_TEST_MODE
    wheel_test_run_once();
    Motor_StopAll();
    uart_send("WHEEL TEST LOCKED. Change WHEEL_TEST_MODE to 0 and reflash.\r\n");
    for (;;)
    {
        HAL_Delay(1000U);
    }

#elif PS2_TEST_MODE
    static uint32_t last_test_reinit_tick = 0;
    if (!PS2_Read())
    {
        Motor_StopAll();
        if ((HAL_GetTick() - last_test_reinit_tick) >= 1000U)
        {
            last_test_reinit_tick = HAL_GetTick();
            PS2_Init();
        }
    }
    PS2_PrintRaw();
    Motor_StopAll();
    HAL_Delay(200U);

#else
    static uint32_t last_reinit_tick = 0;
    uint8_t ok = PS2_Read();

    if (!ok)
    {
        Motor_StopAll();

        /* 手柄没插好时每秒重新初始化一次，支持热插拔 */
        if ((HAL_GetTick() - last_reinit_tick) >= 1000U)
        {
            last_reinit_tick = HAL_GetTick();
            PS2_Init();
        }
    }
    else
    {
        drive_from_ps2();
    }

    HAL_Delay(20U);
#endif
}
