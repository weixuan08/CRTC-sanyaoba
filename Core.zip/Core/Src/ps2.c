#include "ps2.h"
#include "app_config.h"
#include <stdio.h>
#include <string.h>

/* CubeMX 里 USART1 生成的句柄，在 main.c 中定义 */
extern UART_HandleTypeDef huart1;

PS2_Data_t ps2;

/* 半周期 5us，约 100kHz，PS2 接收器完全能接受 */
#define PS2_HALF_US  5U

#define PS2_DAT_HIGH()  (HAL_GPIO_ReadPin(PS2_DAT_GPIO_Port, PS2_DAT_Pin) == GPIO_PIN_SET)
#define PS2_CMD_HIGH()  HAL_GPIO_WritePin(PS2_CMD_GPIO_Port, PS2_CMD_Pin, GPIO_PIN_SET)
#define PS2_CMD_LOW()   HAL_GPIO_WritePin(PS2_CMD_GPIO_Port, PS2_CMD_Pin, GPIO_PIN_RESET)
#define PS2_CLK_HIGH()  HAL_GPIO_WritePin(PS2_CLK_GPIO_Port, PS2_CLK_Pin, GPIO_PIN_SET)
#define PS2_CLK_LOW()   HAL_GPIO_WritePin(PS2_CLK_GPIO_Port, PS2_CLK_Pin, GPIO_PIN_RESET)
#define PS2_CS_HIGH()   HAL_GPIO_WritePin(PS2_CS_GPIO_Port, PS2_CS_Pin, GPIO_PIN_SET)
#define PS2_CS_LOW()    HAL_GPIO_WritePin(PS2_CS_GPIO_Port, PS2_CS_Pin, GPIO_PIN_RESET)

static void ps2_delay_us(uint32_t us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = (SystemCoreClock / 1000000U) * us;

    while ((DWT->CYCCNT - start) < ticks)
    {
    }
}

static uint8_t ps2_transfer(uint8_t tx)
{
    uint8_t rx = 0;

    for (uint8_t i = 0; i < 8U; i++)
    {
        if (tx & (1U << i))
        {
            PS2_CMD_HIGH();
        }
        else
        {
            PS2_CMD_LOW();
        }

        ps2_delay_us(PS2_HALF_US);
        PS2_CLK_LOW();
        ps2_delay_us(PS2_HALF_US);

        if (PS2_DAT_HIGH())
        {
            rx |= (uint8_t)(1U << i);
        }

        PS2_CLK_HIGH();
        ps2_delay_us(PS2_HALF_US);
    }

    return rx;
}

/* 一次 CS 拉低期间连续收发 9 字节 */
static void ps2_packet(const uint8_t tx[9], uint8_t rx[9])
{
    PS2_CS_LOW();
    ps2_delay_us(10U);

    for (uint8_t i = 0; i < 9U; i++)
    {
        rx[i] = ps2_transfer(tx[i]);
        ps2_delay_us(PS2_HALF_US);
    }

    PS2_CS_HIGH();
    ps2_delay_us(10U);
}

void PS2_Init(void)
{
    /* 使能 DWT 周期计数器，用来做微秒延时 */
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

    PS2_CS_HIGH();
    PS2_CMD_HIGH();
    PS2_CLK_HIGH();

    memset(&ps2, 0, sizeof(ps2));
    HAL_Delay(200U);

    /* 进入配置 -> 打开模拟模式 -> 退出配置 */
    static const uint8_t enter_config[9] = {0x01, 0x43, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00};
    static const uint8_t analog_mode[9]  = {0x01, 0x44, 0x00, 0x01, 0x03, 0x00, 0x00, 0x00, 0x00};
    static const uint8_t exit_config[9]  = {0x01, 0x43, 0x00, 0x00, 0x5A, 0x5A, 0x5A, 0x5A, 0x5A};
    uint8_t rx[9];

    ps2_packet(enter_config, rx);
    HAL_Delay(10U);
    ps2_packet(analog_mode, rx);
    HAL_Delay(10U);
    ps2_packet(exit_config, rx);
    HAL_Delay(10U);
}

uint8_t PS2_Read(void)
{
    static const uint8_t poll[9] = {0x01, 0x42, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    uint8_t rx[9];

    ps2_packet(poll, rx);
    memcpy(ps2.raw, rx, sizeof(ps2.raw));
    ps2.mode = rx[1];

    /* 0x5A 是 PS2 帧的固定标志；收不到就认为没接好 */
    if (rx[2] != 0x5A)
    {
        ps2.connected = 0U;
        return 0U;
    }

    ps2.connected = 1U;
    ps2.buttons1 = rx[3];
    ps2.buttons2 = rx[4];
    ps2.right_x  = rx[5];
    ps2.right_y  = rx[6];
    ps2.left_x   = rx[7];
    ps2.left_y   = rx[8];
    return 1U;
}

void PS2_PrintRaw(void)
{
    char buf[240];
    int n;

    if (!ps2.connected)
    {
        static const char msg[] = "PS2: NO RESPONSE (check 3.3V/GND/DAT=B6/CMD=B9/CS=B8/CLK=B7)\r\n";
        HAL_UART_Transmit(&huart1, (uint8_t *)msg, (uint16_t)(sizeof(msg) - 1U), 100U);
        return;
    }

    n = snprintf(buf, sizeof(buf),
                 "RAW %02X %02X %02X %02X %02X %02X %02X %02X %02X | "
                 "MODE=%02X B1=%02X B2=%02X | "
                 "LX=%3u LY=%3u RX=%3u RY=%3u | "
                 "UP=%u DOWN=%u LEFT=%u RIGHT=%u\r\n",
                 (unsigned)ps2.raw[0], (unsigned)ps2.raw[1], (unsigned)ps2.raw[2],
                 (unsigned)ps2.raw[3], (unsigned)ps2.raw[4], (unsigned)ps2.raw[5],
                 (unsigned)ps2.raw[6], (unsigned)ps2.raw[7], (unsigned)ps2.raw[8],
                 (unsigned)ps2.mode, (unsigned)ps2.buttons1, (unsigned)ps2.buttons2,
                 (unsigned)ps2.left_x, (unsigned)ps2.left_y,
                 (unsigned)ps2.right_x, (unsigned)ps2.right_y,
                 (unsigned)PS2_BTN_PRESSED(ps2.buttons1, PS2_DPAD_UP),
                 (unsigned)PS2_BTN_PRESSED(ps2.buttons1, PS2_DPAD_DOWN),
                 (unsigned)PS2_BTN_PRESSED(ps2.buttons1, PS2_DPAD_LEFT),
                 (unsigned)PS2_BTN_PRESSED(ps2.buttons1, PS2_DPAD_RIGHT));

    if (n > 0)
    {
        if (n > (int)sizeof(buf) - 1)
        {
            n = (int)sizeof(buf) - 1;
        }
        HAL_UART_Transmit(&huart1, (uint8_t *)buf, (uint16_t)n, 100U);
    }
}
